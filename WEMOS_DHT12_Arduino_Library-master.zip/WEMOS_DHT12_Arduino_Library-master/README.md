# Arduino library for the WEMOS DHT (DHT12) Shiled

### Installation
- Clone this repository  or download&unzip [zip file](https://github.com/wemos/WEMOS_DHT12_Arduino_Library/archive/master.zip) into Arduino/libraries

